public class Main {
    public static void main(String[] args) {
        Retangulo ret1 = new Retangulo();
        Retangulo ret2 = new Retangulo();

        ret1.setAltura(10.0F);
        ret1.setBase(5.0F);

        ret2.setAltura(10.0F);
        ret2.setBase(15.0F);

        System.out.println("O perímetro do retângulo é:" + ret1.perimetro());
        System.out.println("A área do retângulo é:" + ret1.area());

        System.out.println("\n");

        System.out.println("O perímetro do retângulo é:" + ret2.perimetro());
        System.out.println("A área do retângulo é:" + ret2.area());
    }
}