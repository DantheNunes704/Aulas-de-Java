public class Retangulo {
    private float base;
    private float altura;

    //construtor (default)
    public Retangulo(){
        base = 1;
        altura = 1;
    }

    //get e set
    public float getBase() {
        return base;
    }

    public void setBase(float base) {
        if(base > 1 && base < 20){
            this.base = base;
        }
    }

    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) {
        if(altura > 1 && altura < 20){
            this.altura = altura;
        }
    }

    public float perimetro(){
        return (this.base + this.altura)*2;
    }

    public float area(){
        return this.base*this.altura;
    }
}
