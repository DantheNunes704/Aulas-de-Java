public class Main {
    public static void main(String[] args) {

        Almoco a1 = new Almoco(true, "Carne em cubos", 12, 3.00F);
        Almoco a2 = new Almoco("Frango");
        Almoco a3 = new Almoco("Batata");

        //a2
        System.out.println(a2.getDescricao());
        System.out.println(a2.getPreco());
        //a3
        System.out.println("\n" + a3.getDescricao());
        //a1
        System.out.println(a1.getHorario());
        System.out.println(a1.isQuente());

        a1.setDescricao("Peixe");

        System.out.println("\n"+a1.getDescricao());

        //a1.setDescricao("Macarrão");
        //a1.setsetPreco(3.00);

    }
}