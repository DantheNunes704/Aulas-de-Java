public class Almoco {
    private boolean quente;
    private String descricao;
    private int horario;
    private double preco;

    //construtor
    public Almoco (boolean quente, String descricao, int horario, double preco)
    {
        this.quente = quente;
        this.descricao = descricao;
        this.horario = horario;
        this.preco = preco;
    }

    //sobrecarga
    public Almoco (String descricao)
    {
        this.quente = false;
        this.descricao = descricao;
        this.horario = 0;
        this.preco = 0;
    }

    public Almoco (double preco)
    {
        this.quente = false;
        this.descricao = "";
        this.horario = 0;
        this.preco = preco;
    }

    public Almoco (String descricao, double preco)
    {
        this.quente = false;
        this.descricao = descricao;
        this.horario = 0;
        this.preco = preco;
    }

    //gets e sets
    public boolean isQuente() {
        return quente;
    }

    public void setQuente(boolean quente) {
        this.quente = quente;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getHorario() {
        return horario;
    }

    public void setHorario(int horario) {
        this.horario = horario;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }
}
