public class Cavalo extends Animal{
    //métodos
    @Override
    public void emitirSom()
        {
            System.out.println("relincho");
        }

    public void correr()
    {
        System.out.println("ele está correndo");
    }
}
