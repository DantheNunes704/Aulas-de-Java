public class Preguica extends Animal{
    //métodos
    @Override
    public void emitirSom()
    {
        System.out.println("ronco");
    }

    public void subirEmArvore()
    {
        System.out.println("ele está correndo");
    }
}
