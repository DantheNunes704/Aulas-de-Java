
public class Main {
    public static void main(String[] args) {

        Carro McQueen = new Carro();
        McQueen.modelo = "Uno";
        McQueen.cor = "Vermelho";
        McQueen.marca = "Fiat";
        McQueen.preco = 50873;
        McQueen.km = 1200;

        System.out.println("O modelo do carro McQueen é: " + McQueen.modelo);
        System.out.println("A cor do carro McQueen é: " + McQueen.cor);

        McQueen.ligar();
        McQueen.pintar("Azul");

        System.out.println("\n================================\n");

        Carro Frank = new Carro();
        Frank.modelo = "Fusca";
        Frank.cor = "Amarelo";
        Frank.marca = "Volks";
        Frank.preco = 200000;
        Frank.km = 0;

        System.out.println("Frank");
        System.out.println("Modelo: " + Frank.modelo);
        System.out.println("Cor: " + Frank.cor);
        System.out.println("Preço: " + Frank.preco);
        Frank.aumentarPreco();
        System.out.println("Preço do carro Frank: " + Frank.preco);

    }
}