public class Carro {

    //atributos
        String marca;
        String modelo;
        String cor;
        double preco;
        int km;

    //métodos
        public void ligar (){
            System.out.println("Carro ligando...");
        }

        public double aumentarPreco (){
            preco = preco*1.15;
            return preco;
        }

        public void pintar (String novaCor){
            cor = novaCor;
        }
}