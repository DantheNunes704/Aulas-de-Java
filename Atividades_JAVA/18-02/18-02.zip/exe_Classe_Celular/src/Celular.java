public class Celular {
    Boolean ligado;
    String marca;
    String modelo;

    public void ligar(){
        ligado = true;
    }

    public boolean tocar(){
        if(ligado = true){
            System.out.println("Celular tocando....");
        }
    }
}
