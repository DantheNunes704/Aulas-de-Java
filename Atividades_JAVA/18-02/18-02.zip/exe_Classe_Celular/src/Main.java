
public class Main {
    public static void main(String[] args) {
        Celular cell1 = new Celular();

        cell1.ligado = false;
        cell1.marca = "ceu";
        cell1.modelo = "pocket";

        Celular cell2 = new Celular();

        cell2.ligado = true;
        cell2.marca = "Samsung";
        cell2.modelo = "A71";

        
    }
}