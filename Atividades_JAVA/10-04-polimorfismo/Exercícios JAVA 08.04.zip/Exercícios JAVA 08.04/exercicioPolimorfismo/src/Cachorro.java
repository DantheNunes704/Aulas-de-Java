public class Cachorro extends Animal{
    //métodos
    @Override
    public void emitirSom()
    {
        System.out.println("latido");
    }

    public void correr()
    {
        System.out.println("ele está correndo");
    }
}
