public class Main {
    public static void main(String[] args) {
        Animal a1 = new Cavalo();
        Animal a2 = new Preguica();
        Animal a3 = new Cachorro();

        a1.emitirSom();
        a2.emitirSom();
        a3.emitirSom();

    }
}