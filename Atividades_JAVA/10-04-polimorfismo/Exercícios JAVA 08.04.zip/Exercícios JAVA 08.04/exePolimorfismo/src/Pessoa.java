public class Pessoa {
    protected String nome;

    //construtor
    public Pessoa(String nome)
    {
        this.nome = nome;
    }

    //gets e sets
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    //métodos
    public void mostrar()
    {
        System.out.println("é uma pessoa");
    }
}
