public class Main {
    public static void main(String[] args) {
        Pessoa p1 = new Pessoa("EI");
        p1.mostrar();

        Pessoa p2 = new Pessoa("oba");

        Aluno a1 = new Aluno("A", 2323);
        a1.mostrar();

        Aluno a2 = (Aluno) p2;
        a2.estudar();

        if(a2 instanceof Object)
        {
            System.out.println("é instância");
        }
    }
}