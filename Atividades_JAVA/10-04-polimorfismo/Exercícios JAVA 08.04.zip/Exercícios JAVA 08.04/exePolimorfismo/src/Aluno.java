public class Aluno extends Pessoa{
    private int ra;

    //construtor
    public Aluno(String nome, int ra)
    {
        super(nome);
        this.ra = ra;
    }


    //métodos

    @Override
    public void mostrar()
    {
        System.out.println("É um aluno");
    }

    public void estudar()
    {
        System.out.println("Está estudando");
    }
}
