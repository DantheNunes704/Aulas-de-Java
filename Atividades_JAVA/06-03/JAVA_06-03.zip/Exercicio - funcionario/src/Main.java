public class Main {
    public static void main(String[] args) {
        Funcionario func1 = new Funcionario();
        Funcionario func2 = new Funcionario();

        func1.setNome("Cláudio");
        func1.setSobrenome("Ribeiro");
        func1.setSalario(3400);

        func2.setNome("Whinderson");
        func2.setSobrenome("Nunes");
        func2.setSalario(5600);

        System.out.println("O salário anual de " + func1.getNome() + " é:" + func1.salarioAno());
        System.out.println("O salário anual de " + func2.getNome() + " é:" + func2.salarioAno());

        func1.aumento();
        func2.aumento();

        System.out.println("O salário anual de " + func1.getNome() + " é:" + func1.salarioAno());
        System.out.println("O salário anual de " + func2.getNome() + " é:" + func2.salarioAno());
    }
}