public class Funcionario {
    private String nome;
    private String sobrenome;
    private double salario;

    //construtor
    public Funcionario(){
        this.nome = "";
        this.sobrenome = "";
        this.salario = 0;
    }

    //gets e sets
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        if(salario > 0){
            this.salario = salario;
        }
        else{
            this.salario = 0;
        }

    }

    public double salarioAno(){
        return this.salario*12;
    }

    public void aumento(){
        this.salario*=1.1;
    }
}
