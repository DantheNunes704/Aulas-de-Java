public class Item{
    private int codigo;
    private String descricao;
    private int quantComprada;
    private double preco;

    //construtor
    public Item(){
        this.codigo = 0;
        this.descricao = "";
        this.quantComprada = 0;
        this.preco = 0;
    }

    //gets e sets
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getQuantComprada() {
        return quantComprada;
    }

    public void setQuantComprada(int quantComprada) {
        if(quantComprada>0){
            this.quantComprada = quantComprada;
        }
        else{
            this.quantComprada = 0;
        }
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        if(preco>0){
            this.preco = preco;
        }
        else{
            this.preco = 0;
        }

    }

    //metodos
    public double getTotal(){
        return this.preco*this.quantComprada;
    }
}
