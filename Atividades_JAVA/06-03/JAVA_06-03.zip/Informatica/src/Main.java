public class Main {
    public static void main(String[] args) {
        Item computador = new Item();
        computador.setCodigo(1);
        computador.setPreco(4500);
        computador.setDescricao("Para serviços ou lazer");
        computador.setQuantComprada(5);

        Item celular = new Item();
        celular.setCodigo(2);
        celular.setPreco(7800);
        celular.setDescricao("Para jogos");
        celular.setQuantComprada(17);

        System.out.println("Sobre o produto:" + computador.getDescricao());
        System.out.println("Código do produto:" + computador.getCodigo());
        System.out.println("Quantidade do produto:" + computador.getQuantComprada());
        System.out.println("Preço do produto:" + computador.getPreco());
        System.out.println("Quantidade total a pagar:" + computador.getTotal() + "\n\n");

        System.out.println("Sobre o produto:" + celular.getDescricao());
        System.out.println("Código do produto:" + celular.getCodigo());
        System.out.println("Quantidade do produto:" + celular.getQuantComprada());
        System.out.println("Preço do produto:" + celular.getPreco());
        System.out.println("Quantidade total a pagar:" + celular.getTotal() + "\n\n");
    }
}