public class Teclado {
    String cor;
    int codigo;
    int numeroTeclas;

    public void teclar(){
        System.out.println("Você teclou no teclado");
    }

    public void aumentarTeclas(){
        numeroTeclas+=10;
    }

}
