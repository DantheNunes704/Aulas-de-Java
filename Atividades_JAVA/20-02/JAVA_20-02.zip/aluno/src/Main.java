import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String novoProfessor;

        Aluno aluno1 = new Aluno();
        Aluno aluno2 = new Aluno();

        Disciplina materia1 = new Disciplina();
        Disciplina materia2 = new Disciplina();

        materia1.nome = "matematica";
        materia1.professorResponsavel = "Prips";
        materia1.codigo = 1245;
        materia1.cargaHoraria = 230;

        materia2.nome = "fisica";
        materia2.professorResponsavel = "Xandão";
        materia2.codigo = 2345678;
        materia2.cargaHoraria = 700;

        aluno1.idade = 7;
        aluno1.nome = "Sheldon";
        aluno1.turma = "Segundo ano do ensino fundamental";
        aluno1.RA = 203088;
        aluno1.altura = 1.30F;

        aluno2.idade = 16;
        aluno2.nome = "George";
        aluno2.turma = "Segundo ano do ensino médio";
        aluno2.RA = 207066;
        aluno2.altura = 1.75F;



        aluno1.fazerAniversario();
        aluno1.estudar();

        aluno2.fazerAniversario();
        aluno2.estudar();

        System.out.println("\n====================\n");

        System.out.println("aluno1:");
        System.out.println("nome: " + aluno1.nome);
        System.out.println("turma: " + aluno1.turma);
        System.out.println("altura: " + aluno1.altura);
        System.out.println("RA: " + aluno1.RA);
        System.out.println("idade: " + aluno1.idade);
        System.out.println("++++++++++++++++++++++++");
        System.out.println("aluno2:");
        System.out.println("nome: " + aluno2.nome);
        System.out.println("turma: " + aluno2.turma);
        System.out.println("altura: " + aluno2.altura);
        System.out.println("RA: " + aluno2.RA);
        System.out.println("idade: " + aluno2.idade);

        System.out.println("\n=======================\n");

        //System.out.println("Digite o nome do novo professor:");
        //novoProfessor = scan.nextLine();
        materia1.novoProfessor("alberto");
        materia1.aumentarCargaHoraria();

        //System.out.println("Digite o nome do novo professor:");
        //novoProfessor = scan.nextLine();
        materia2.novoProfessor("rogerio");
        materia2.aumentarCargaHoraria();

        System.out.println("Materia 1:");
        System.out.println("Nome da matéria: " + materia1.nome);
        System.out.println("Professor Responsável: " + materia1.professorResponsavel );
        System.out.println("Código: " + materia1.codigo );
        System.out.println("Carga Horária: " + materia1.cargaHoraria);
        System.out.println("++++++++++++++++++++++++");
        System.out.println("Materia 2:");
        System.out.println("Nome da matéria: " + materia2.nome);
        System.out.println("Professor Responsável: " + materia2.professorResponsavel );
        System.out.println("Código: " + materia2.codigo );
        System.out.println("Carga Horária: " + materia2.cargaHoraria);

        System.out.println("\n=======================\n");

        Teclado tec1 = new Teclado();
        Teclado tec2 = new Teclado();

        tec1.cor = "Vermelho";
        tec1.numeroTeclas = 22;
        tec1.codigo = 6748;

        tec2.cor = "Rosa";
        tec2.numeroTeclas = 37;
        tec2.codigo = 4582;

        tec1.aumentarTeclas();
        tec1.teclar();

        tec2.aumentarTeclas();
        tec2.teclar();
        System.out.println("\n=======================\n");

        System.out.println("Teclado 1:");
        System.out.println("Número de teclas: " + tec1.numeroTeclas);
        System.out.println("Código: " + tec1.codigo);
        System.out.println("Cor: " + tec1.cor);
        System.out.println("++++++++++++++++++++++++");
        System.out.println("Teclado 2:");
        System.out.println("Número de teclas: " + tec2.numeroTeclas);
        System.out.println("Código: " + tec2.codigo);
        System.out.println("Cor: " + tec2.cor);

        System.out.println("\n=======================\n");
    }
}