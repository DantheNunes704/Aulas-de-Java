public class Aluno {
    String nome;
    String turma;
    int RA;
    int idade;
    float altura;

    public void estudar(){
        System.out.println("Aluno estudando.\n");
    }

    public void fazerAniversario(){
        idade+=1;
    }
}
