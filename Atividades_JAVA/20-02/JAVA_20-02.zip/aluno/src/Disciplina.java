import java.util.Scanner;

public class Disciplina {


    String nome;
    String professorResponsavel;
    int codigo;
    int cargaHoraria;

    public void novoProfessor(String novoProfessor){


        professorResponsavel = novoProfessor;
    }

    public void aumentarCargaHoraria(){
        cargaHoraria+=20;
    }
}
