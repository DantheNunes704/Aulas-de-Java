import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        double salario_maior=0, salario, media_salario=0;
        int filhos_med=0, poplc=0, poplc_menor=0;

        Scanner teclado = new Scanner (System.in);

        System.out.println("Digite seu salário: ");
        salario = teclado.nextDouble();

        while(salario > 0){
            System.out.println("Digite quantos filhos você tem: ");
            filhos_med += teclado.nextInt();

            media_salario += salario;

            if(salario_maior < salario){
                salario_maior = salario;
            }

            if(salario < 150){
                poplc_menor++;
            }

            poplc++;

            System.out.println("Digite seu salário: ");
            salario = teclado.nextDouble();
        }

        System.out.println("Média de salário da população: " + (media_salario/poplc));
        System.out.println("Média do número de filhos da população: " + (filhos_med/poplc));
        System.out.println("Maior salário dos habitantes: " + salario_maior);
        System.out.println("Percentual de pessoas com salário menor que 150: %" + (poplc_menor/poplc));
    }
}