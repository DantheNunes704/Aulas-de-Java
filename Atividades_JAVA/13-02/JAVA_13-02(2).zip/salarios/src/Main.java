import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        double salario, salario_M=0, salario_F=0;
        char sexo;

        Scanner teclado = new Scanner (System.in);

        salario = teclado.nextDouble();

        System.out.println("Digite o seu salário:");
        salario = teclado.nextDouble();

        while(salario > 0){

            System.out.println("Digite o seu sexo:");
            sexo = teclado.next().charAt(0);

            if(sexo == 'M'){
                salario_M += salario;
            }
            else{
                salario_F += salario;
            }
            System.out.println("Digite o seu salário:");
            salario = teclado.nextDouble();
        }

        System.out.println("Total do salário pago às mulheres: " + salario_F);
        System.out.println("Total do salário pago aos homens: " + salario_M);

    }
}