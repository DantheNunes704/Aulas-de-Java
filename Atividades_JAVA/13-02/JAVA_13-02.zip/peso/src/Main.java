import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        float peso=0, pesoM=0, mulher=0;
        char sexo;

        Scanner teclado = new Scanner (System.in);

        for(int n = 0; n<4; n++){
            System.out.println("Digite o seu sexo:");
            sexo = teclado.next().charAt(0);
            System.out.println("Digite o seu peso:");
            peso = teclado.nextFloat();

                if(sexo == 'M' || sexo == 'm' && peso>100) {
                    pesoM++;
                }

                if (sexo == 'F' || sexo == 'f'){
                    mulher++;
                }
            }
        System.out.println("Total de mulheres cadastradas: " + mulher);
        System.out.println("Total de homens acima de 100KG: " + pesoM);
        }
    }