import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        float quant=0, idade=0, soma=0;

        Scanner teclado = new Scanner (System.in);

        do
        {
            System.out.println("Digite a sua idade");
            idade = teclado.nextInt();
            if(idade != 999){
                soma += idade;
                quant++;
            }

        }while(idade != 999);
        System.out.println("Quantidade de alunos na sala de aula: " + quant);
        if(quant == 0){
            quant++;
        }
        System.out.println("Média da idade dos alunos: " + (soma/quant));

    }
}